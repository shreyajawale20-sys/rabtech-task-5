package com.rabtech.secureauth.auth;

import com.rabtech.secureauth.security.CustomUserDetailsService;
import com.rabtech.secureauth.security.JwtService;
import com.rabtech.secureauth.user.AppUser;
import com.rabtech.secureauth.user.AppUserRepository;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.*;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AppUserRepository repository;
    private final PasswordEncoder encoder;
    private final AuthenticationManager authenticationManager;
    private final CustomUserDetailsService userDetailsService;
    private final JwtService jwtService;

    public AuthController(AppUserRepository repository, PasswordEncoder encoder,
                          AuthenticationManager authenticationManager,
                          CustomUserDetailsService userDetailsService, JwtService jwtService) {
        this.repository = repository;
        this.encoder = encoder;
        this.authenticationManager = authenticationManager;
        this.userDetailsService = userDetailsService;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest request) {
        if (repository.existsByUsername(request.username())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("error", "Username already exists"));
        }
        AppUser user = repository.save(new AppUser(
                request.username(), encoder.encode(request.password()), "USER"));
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                "message", "User registered successfully",
                "username", user.getUsername(),
                "role", "USER"
        ));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.username(), request.password()));
        UserDetails user = userDetailsService.loadUserByUsername(request.username());
        return ResponseEntity.ok(Map.of(
                "message", "Login successful",
                "tokenType", "Bearer",
                "token", jwtService.generateToken(user),
                "expiresInMs", 3600000
        ));
    }

    public record RegisterRequest(@NotBlank @Size(min=3, max=80) String username,
                                  @NotBlank @Size(min=8, max=100) String password) {}
    public record LoginRequest(@NotBlank String username, @NotBlank String password) {}
}
