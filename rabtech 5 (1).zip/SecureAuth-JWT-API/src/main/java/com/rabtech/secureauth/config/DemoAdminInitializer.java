package com.rabtech.secureauth.config;

import com.rabtech.secureauth.user.AppUser;
import com.rabtech.secureauth.user.AppUserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DemoAdminInitializer {
    @Bean
    CommandLineRunner createDemoAdmin(AppUserRepository repository, PasswordEncoder encoder) {
        return args -> {
            if (!repository.existsByUsername("admin")) {
                repository.save(new AppUser("admin", encoder.encode("Admin@12345"), "ADMIN"));
            }
        };
    }
}
