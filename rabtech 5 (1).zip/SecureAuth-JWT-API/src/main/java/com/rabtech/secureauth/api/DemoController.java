package com.rabtech.secureauth.api;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class DemoController {
    @GetMapping("/public/hello")
    public Map<String, String> hello() {
        return Map.of("message", "Hello! This is a public endpoint.");
    }

    @GetMapping("/user/profile")
    public Map<String, String> profile(Authentication authentication) {
        return Map.of("message", "You accessed a protected user endpoint.",
                "username", authentication.getName(), "role", "USER or ADMIN");
    }

    @GetMapping("/admin/dashboard")
    public Map<String, String> admin(Authentication authentication) {
        return Map.of("message", "Welcome to the admin dashboard.",
                "username", authentication.getName(), "requiredRole", "ADMIN");
    }
}
